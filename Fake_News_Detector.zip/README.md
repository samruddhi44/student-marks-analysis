
# 📰 Fake News Detector

This mini-project is a beginner-friendly implementation of a **Fake News Detection** model using Python and machine learning.

## 📁 Files Included
- `news.csv` — Small sample dataset of real and fake news
- `fake_news_detector.py` — Python code to train and test the model

## 📌 Tools Used
- `Pandas`, `scikit-learn`, `TfidfVectorizer`, `PassiveAggressiveClassifier`

## 🚀 How to Run
1. Install requirements:
   ```bash
   pip install pandas scikit-learn
   ```

2. Run the script:
   ```bash
   python fake_news_detector.py
   ```

✅ This project shows how to preprocess text, train a model, and measure accuracy.

Feel free to try it with your own dataset!
