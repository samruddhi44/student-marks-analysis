
# 🧠 Student Marks Analysis

This beginner project helps analyze student marks using Python, Pandas, and Matplotlib.

## 📁 Files Included
- `student_marks.csv` — Sample student marks data
- `analyze_marks.py` — Python script to load and analyze the data
- `marks_plot.png` — Generated bar plot showing student performance

## 🚀 How to Run
1. Make sure you have Python installed.
2. Install the required libraries using:
   ```bash
   pip install pandas matplotlib
   ```
3. Run the script:
   ```bash
   python analyze_marks.py
   ```

This is a great beginner project to understand how to use Pandas and visualize data in Python.
