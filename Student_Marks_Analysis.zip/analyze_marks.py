
import pandas as pd
import matplotlib.pyplot as plt

# Load the data
df = pd.read_csv("student_marks.csv")

# Print basic statistics
print("Subject-wise Average Marks:")
print(df[['Maths', 'Science', 'English']].mean())

# Plot marks of each student
df.plot(x='Name', kind='bar', figsize=(10,6))
plt.title("Student Marks Analysis")
plt.ylabel("Marks")
plt.xlabel("Students")
plt.grid(True)
plt.tight_layout()
plt.savefig("marks_plot.png")
plt.show()
